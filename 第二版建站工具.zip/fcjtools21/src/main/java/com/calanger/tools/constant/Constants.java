package com.calanger.tools.constant;

public final class Constants {
    public static final String DEFAULT_CHARSET = "UTF-8";

    private Constants() {
    }
}
